/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class _7f140ec8C5e44be3Bbca7c8e45ad912a extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "7F140EC8-C5E4-4BE3-BBCA-7C8E45AD912A",
        "./_7f140ec8C5e44be3Bbca7c8e45ad912a/costumes/7F140EC8-C5E4-4BE3-BBCA-7C8E45AD912A.png",
        { x: 74, y: 266 }
      ),
      new Costume(
        "costume1",
        "./_7f140ec8C5e44be3Bbca7c8e45ad912a/costumes/costume1.png",
        { x: 68, y: 274 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Poop" }, this.whenIReceivePoop)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "7F140EC8-C5E4-4BE3-BBCA-7C8E45AD912A";
  }

  *whenIReceivePoop() {
    this.costume = "costume1";
  }
}
