import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Sprite1 from "./Sprite1/Sprite1.js";
import F2d3f817Ceb74f16A815F07530363995 from "./F2d3f817Ceb74f16A815F07530363995/F2d3f817Ceb74f16A815F07530363995.js";
import _7f140ec8C5e44be3Bbca7c8e45ad912a from "./_7f140ec8C5e44be3Bbca7c8e45ad912a/_7f140ec8C5e44be3Bbca7c8e45ad912a.js";
import GreenFlag from "./GreenFlag/GreenFlag.js";
import Sprite2 from "./Sprite2/Sprite2.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Sprite1: new Sprite1({
    x: -212,
    y: 147,
    direction: 75,
    costumeNumber: 2,
    size: 100,
    visible: true
  }),
  F2d3f817Ceb74f16A815F07530363995: new F2d3f817Ceb74f16A815F07530363995({
    x: -57.17647058823528,
    y: -48.17647058823529,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: true
  }),
  _7f140ec8C5e44be3Bbca7c8e45ad912a: new _7f140ec8C5e44be3Bbca7c8e45ad912a({
    x: -105.05882352941178,
    y: 30.882352941176464,
    direction: 90,
    costumeNumber: 2,
    size: 100,
    visible: true
  }),
  GreenFlag: new GreenFlag({
    x: 36.82352941176471,
    y: 122.23529411764707,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true
  }),
  Sprite2: new Sprite2({
    x: 1,
    y: 1,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true
  })
};

const project = new Project(stage, sprites);
export default project;
