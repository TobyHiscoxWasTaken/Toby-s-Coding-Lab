/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class F2d3f817Ceb74f16A815F07530363995 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "F2D3F817-CEB7-4F16-A815-F07530363995",
        "./F2d3f817Ceb74f16A815F07530363995/costumes/F2D3F817-CEB7-4F16-A815-F07530363995.png",
        { x: -72, y: 175 }
      ),
      new Costume(
        "costume1",
        "./F2d3f817Ceb74f16A815F07530363995/costumes/costume1.png",
        { x: -84, y: 127 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.BROADCAST, { name: "Bruh" }, this.whenIReceiveBruh),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenIReceiveBruh() {
    this.costume = "costume1";
  }

  *whenGreenFlagClicked() {
    this.costume = "F2D3F817-CEB7-4F16-A815-F07530363995";
  }
}
