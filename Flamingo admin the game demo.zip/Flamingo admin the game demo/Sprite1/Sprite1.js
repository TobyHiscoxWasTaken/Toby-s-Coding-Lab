/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite1/costumes/costume1.svg", {
        x: 0,
        y: 0
      }),
      new Costume(
        "304B9A5F-7812-4093-B492-0F3C6DC0100E",
        "./Sprite1/costumes/304B9A5F-7812-4093-B492-0F3C6DC0100E.png",
        { x: 200, y: -116 }
      )
    ];

    this.sounds = [new Sound("pop", "./Sprite1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.KEY_PRESSED, { key: "b" }, this.whenKeyBPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "f" }, this.whenKeyFPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "w" }, this.whenKeyWPressed)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      yield* this.glide(0, this.mouse.x, this.mouse.y);
      yield;
    }
  }

  *whenKeyBPressed() {
    if (
      this.touching(
        this.sprites["F2d3f817Ceb74f16A815F07530363995"].andClones()
      )
    ) {
      this.broadcast("Bruh");
    }
  }

  *whenKeyFPressed() {
    this.broadcast("Poop");
  }

  *whenKeyWPressed() {
    if (this.touching(this.sprites["GreenFlag"].andClones())) {
      this.broadcast("Winn");
    }
  }
}
