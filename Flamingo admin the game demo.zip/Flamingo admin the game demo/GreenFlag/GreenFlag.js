/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class GreenFlag extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("green flag", "./GreenFlag/costumes/green flag.svg", {
        x: 70,
        y: 30
      })
    ];

    this.sounds = [new Sound("pop", "./GreenFlag/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Poop" }, this.whenIReceivePoop),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(Trigger.BROADCAST, { name: "Winn" }, this.whenIReceiveWinn)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceivePoop() {
    this.visible = true;
  }

  *whenKeySpacePressed() {}

  *whenIReceiveWinn() {
    this.visible = true;
  }
}
