/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Sprite2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Sprite2/costumes/costume1.png", {
        x: 480,
        y: 360
      })
    ];

    this.sounds = [new Sound("pop", "./Sprite2/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Winn" }, this.whenIReceiveWinn),
      new Trigger(Trigger.BROADCAST, { name: "Winn" }, this.whenIReceiveWinn2)
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(-212, 42);
    this.visible = false;
  }

  *whenIReceiveWinn() {}

  *whenIReceiveWinn2() {
    this.goto(1, 1);
    this.visible = true;
  }
}
